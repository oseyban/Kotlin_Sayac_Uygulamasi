package com.os.kotlin_sayac_uygulamasi

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val baslatButton = findViewById<Button>(R.id.button)
        baslatButton.setOnClickListener {
            sayac()
        }

    }

    fun sayac() {
        val sayi = findViewById<EditText>(R.id.editText)
        val sayiStr = sayi.text.toString()

        // Girilen sayının geçerli bir tam sayı olup olmadığını kontrol et
        if (sayiStr.isEmpty()) {
            Toast.makeText(this, "Lütfen bir sayı giriniz", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val sayiInt = sayiStr.toInt()
            object : CountDownTimer((sayiInt * 1000).toLong(), 1000) {
                override fun onTick(SS: Long) {
                    val sayacyazdir = findViewById<TextView>(R.id.textView)
                    sayacyazdir.text = "Sayac: ${SS /1000}"
                }

                override fun onFinish() {
                    val sayacyazdir = findViewById<TextView>(R.id.textView)
                    sayacyazdir.text = "Bitti"
                }
            }.start()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Geçerli bir sayı giriniz", Toast.LENGTH_SHORT).show()
        }
    }
}
